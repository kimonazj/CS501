package com.example.researchproject;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class searchClass extends AppCompatActivity {

    private Button Back;
    public void backFunction(){
        Intent intent = new Intent(searchClass.this, MainActivity2.class);
        startActivity(intent);
    }

    private Button browse;
    private Button upload;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.search);

        Back = findViewById(R.id.back);
        browse = findViewById(R.id.find);
        upload = findViewById(R.id.upload);
    }
}
